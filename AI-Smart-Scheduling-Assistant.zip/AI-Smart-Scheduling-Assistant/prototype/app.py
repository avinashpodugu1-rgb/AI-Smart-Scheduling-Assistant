import streamlit as st
st.title("AI Smart Scheduling Assistant")
st.write("Prototype demo")
name=st.text_input("Customer")
date=st.date_input("Preferred date")
if st.button("Recommend"):
    st.success(f"Recommended booking for {name} on {date}.")
